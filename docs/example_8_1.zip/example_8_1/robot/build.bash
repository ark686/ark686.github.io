xacro robot/robot.urdf.xacro > robot/robot.urdf 2>> log/robot_build
gz sdf -p robot/robot.urdf > robot/robot.sdf 2>> log/robot_build