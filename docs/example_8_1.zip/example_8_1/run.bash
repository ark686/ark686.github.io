. /opt/ros/jazzy/setup.sh

# Make log subdirectory if it does not exist
mkdir -p log

# Echo date/time to log file
DATE=`date`
echo "$DATE run.bash:" &>> log/run

# Stop any old processes
. stop.bash

# Build robot model
. robot/build.bash

# Run robot state publsiher
ros2 run robot_state_publisher robot_state_publisher ./robot/robot.urdf &>> log/robot_state_publisher &

# Run bridge
ros2 run ros_gz_bridge parameter_bridge --ros-args -p config_file:=bridges.yaml -p use_sim_time:=true &>> log/ros_gz_bridge &

# Static transforms
ros2 run tf2_ros static_transform_publisher --frame-id laser_frame --child-frame-id robot1/base_link/lidar --ros-args -p use_sim_time:=true &>> log/static_tf &

# Run gazebo
gz sim world/world.sdf -r --gui-config world/gazebo.config &>> log/gazebo &

# Run Rviz
rviz2 -d rviz.rviz &>> log/rviz2 &

/opt/ros/jazzy/lib/nav2_map_server/map_server --ros-args -p yaml_filename:=ex_7_1.yaml -p use_sim_time:=true &>> log/map_server &
/opt/ros/jazzy/lib/nav2_amcl/amcl --ros-args -p use_sim_time:=true --params-file amcl.yaml &>> log/amcl &
/opt/ros/jazzy/lib/nav2_lifecycle_manager/lifecycle_manager --ros-args --log-level info --ros-args -r __node:=lifecycle_manager_localization -p use_sim_time:=True --params-file localization.yaml &>> log/localization &

ros2 launch navigation_launch.py use_sim_time:=true

. stop.bash

# Echo date/time to log file
DATE=`date`
echo "$DATE run DONE" &>> log/run
