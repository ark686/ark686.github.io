. /opt/ros/jazzy/setup.sh

# Make log subdirectory if it does not exist
mkdir -p log

# Echo date/time to log file
DATE=`date`
echo "$DATE run.bash:" &>> log/run

# Build robot model
. robot/build.bash

ros2 launch main_launch.py use_sim_time:=true

# Echo date/time to log file
DATE=`date`
echo "$DATE run DONE" &>> log/run
