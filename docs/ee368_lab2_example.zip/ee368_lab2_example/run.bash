# Make log subdirectory if it does not exist
mkdir -p log

# Echo date/time to log file
DATE=`date`
echo "$DATE run.bash:" &>> log/run

# Stop any old processes
. stop.bash

# Build the single URDF file using xacro
cd robot
. build.bash
cd ..

# Run robot_state_publisher using generated single URDF file
ros2 run robot_state_publisher robot_state_publisher ./robot/robot.urdf &>> log/robot_state_publisher &

# Run joint_state_publister_gui
ros2 run joint_state_publisher_gui joint_state_publisher_gui &>> log/joint_state_publisher_gui &

# Run rviz2 with config file
rviz2 -d rviz2.rviz &>> log/rviz2 &
