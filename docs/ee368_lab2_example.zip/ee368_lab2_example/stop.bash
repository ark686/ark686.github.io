function MyKillAll () {
    PROG=$1
    CMD="ps ax|grep '$PROG'|grep -v grep|awk '{\$1=\$1};1'|cut -f 1 -d ' '"
    PS=$(eval "$CMD")
    IFS=$'\n'
    for item in $PS
    do
        echo "Killing $PROG: $item" &>> log/stop
        kill -9 $item &>> log/stop
    done
} 

DATE=`date`
echo "$DATE stop.bash:" &>> log/stop
MyKillAll "robot_state_publisher"
MyKillAll "joint_state_publisher_gui"
MyKillAll "rviz2"


