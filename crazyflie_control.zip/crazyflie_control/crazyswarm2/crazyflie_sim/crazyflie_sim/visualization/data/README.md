# Acknowledgments 

- All background images are in the public domain (CC0 license) and were sourced from [polyhaven.com](https://polyhaven.com/) 
- The crazyflie model used is under an MIT license and was modified and sourced from [https://github.com/bitcraze/crazyflie-simulation](https://github.com/bitcraze/crazyflie-simulation)

