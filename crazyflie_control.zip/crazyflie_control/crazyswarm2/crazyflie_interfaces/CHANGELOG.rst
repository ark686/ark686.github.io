^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package crazyflie_interfaces
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.2 (2025-07-02)
------------------
* Add additional dependencies to address ROSfarm build failures
* Contributors: Wolfgang Hönig

1.0.1 (2025-06-30)
------------------
* Fix build errors and dependencies on ROS Build Farm
* Contributors: Kimberly N. McGuire, Wolfgang Hönig

1.0.0 (2025-06-21)
------------------
* First official release.
* Contributors: Khaled Wahba, Kimberly McGuire, Wolfgang Hönig, phanfeld
