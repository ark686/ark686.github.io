# pragma once

namespace bitcraze {
namespace crazyflieLinkCpp {

const char* version();

} // namespace crazyflieLinkCpp
} // namespace bitcraze